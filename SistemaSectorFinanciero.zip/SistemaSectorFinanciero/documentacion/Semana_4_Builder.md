# Semana 4 — Patrón BUILDER

## 1. ¿Qué es el patrón Builder?

Es un patrón de diseño **creacional** que construye objetos complejos paso a
paso. Permite configurar únicamente los datos necesarios sin utilizar
constructores gigantes con muchos parámetros opcionales.

**¿Por qué en un banco?** Los préstamos y las inversiones tienen varios datos
opcionales, como garantía, seguro, tasa, plazo y perfil de riesgo. El Builder
permite ensamblar cada producto de forma ordenada y legible.

---

## 2. ¿Dónde está en el código?

Archivo: **`builders.py`**

| Pieza del patrón | Código |
|---|---|
| Productos | `Prestamo` e `Inversion` |
| Builders | `PrestamoBuilder` e `InversionBuilder` |
| Directores | `PrestamoDirector` e `InversionDirector` |
| Rutas que lo usan | `/prestamos` y `/inversiones` |

### Código clave

El Builder de préstamos permite encadenar pasos:

```python
builder = PrestamoBuilder()
prestamo = (
    builder.cliente(cliente_id)
    .tipo("PERSONAL")
    .monto(monto)
    .plazo(meses)
    .tasa_interes(0.12)
    .con_seguro(monto * 0.01)
    .construir()
)
```

El Director contiene recetas listas para los tipos de préstamo:

```python
director = PrestamoDirector()
director.prestamo_personal(builder, cliente_id, monto, meses)
```

La cabecera de `builders.py` indica: `SEMANA 4 - PATRON BUILDER`.

---

## 3. ¿Qué hace dentro del sistema?

### Préstamos

1. El usuario selecciona el tipo de préstamo, monto y plazo.
2. `PrestamoDirector` elige la receta correspondiente: Personal,
   Hipotecario o Vehicular.
3. `PrestamoBuilder` agrega el cliente, monto, plazo, tasa, garantía y seguro
   mediante pasos encadenables.
4. `construir()` devuelve el préstamo completo.
5. El sistema calcula la cuota mensual y guarda el préstamo en la base de datos.

### Inversiones

1. El usuario selecciona el perfil de riesgo: Conservador, Moderado o Agresivo.
2. `InversionDirector` elige el producto, la tasa y el plazo adecuados.
3. `InversionBuilder` ensambla el inversor, tipo, monto, tasa, plazo y perfil.
4. `construir()` valida y guarda la inversión.
5. El sistema calcula la rentabilidad estimada.

---

## 4. Funciones de la página relacionadas

| Página | Cómo se ve el patrón en uso |
|---|---|
| **Préstamos** (`/prestamos`) | Al solicitar un préstamo, el Builder lo ensambla paso a paso según el tipo elegido. |
| **Inversiones** (`/inversiones`) | Al crear una inversión, el Builder la ensambla según el perfil de riesgo. |
| **Dashboard** (`/`) | Muestra los últimos préstamos e inversiones creados. |

---

## 5. Cómo probarlo desde el front

1. Entra con `maria / 1234`.
2. Ve a **Préstamos** y crea un préstamo Personal, Hipotecario o Vehicular.
3. Comprueba que se calculen la cuota y los datos específicos del tipo elegido.
4. Ve a **Inversiones** y crea una inversión con un perfil de riesgo.
5. Comprueba que se muestre la rentabilidad estimada.

---

## 6. Estructura del patrón

```
PrestamoBuilder                         InversionBuilder
      │                                        │
      ├── cliente()                            ├── inversor()
      ├── tipo()                               ├── tipo()
      ├── monto()                              ├── monto()
      ├── plazo()                              ├── tasa()
      ├── tasa_interes()                       ├── plazo()
      ├── con_garantia()                       ├── perfil()
      ├── con_seguro()                         └── construir()
      └── construir()

PrestamoDirector                         InversionDirector
      │                                        │
      ├── Personal                             ├── Conservador
      ├── Hipotecario                          ├── Moderado
      └── Vehicular                            └── Agresivo
```
